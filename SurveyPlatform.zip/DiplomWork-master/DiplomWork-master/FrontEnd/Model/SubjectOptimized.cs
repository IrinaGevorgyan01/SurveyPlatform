namespace FrontEnd.Model;

public class SubjectOptimized
{
    public int Id { get; set; }
    public double Hour { get; set; }
}