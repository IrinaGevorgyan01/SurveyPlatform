namespace BackEnd.Models.Output;

public class Semester
{
    public int Id { get; set; }
    public int Hours { get; set; }
    public string Name { get; set; }
}