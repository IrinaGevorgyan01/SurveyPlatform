namespace BackEnd.Helpers;

public class BaseParam
{
    public int DepartmentId { get; set;}
    public int RoleId { get; set;} 
}