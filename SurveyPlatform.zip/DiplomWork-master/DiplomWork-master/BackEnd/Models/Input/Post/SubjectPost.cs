namespace BackEnd.Models.Input.Post;

public class SubjectPost
{
    public string? Title { get; set; }
    public string? Outcome { get; set; }
    public int OutcomeTypeId { get; set; }
    public int DepartmentId { get; set; }
    public int? HoursPerSem { get; set; }
}