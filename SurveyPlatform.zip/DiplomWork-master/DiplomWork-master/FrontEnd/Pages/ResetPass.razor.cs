﻿
using FrontEnd.Interface;
using FrontEnd.Model;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;


namespace FrontEnd.Pages;

public partial class ResetPass
{
    //[Inject]
    //private IAuthorizationService Authorization { get; set; }
    

    //[Inject]
    //protected IJSRuntime js { get; set; }
    
    //private AuthorizationPost _model = new();
    
    //private async void Authorize()
    //{
    //    object s = "121112131";
    //    try
    //    {
    //        s =  await this.Authorization.AuthorizeClient(_model);
    //    }
    //    finally
    //    {
    //        s = "error";
    //    }

    //   // await JSRuntime.InvokeVoidAsync("alert", s);
    //   //await js.Alert(s);
    //   _model.LogIn = "jwjjwesadjsdjf";
    //}
}