﻿namespace FrontEnd.Model.BL;
public class ScheduleRowBl
{
    
    public int Id { get; set; }
    public int ScheduleId { get; set; }
    public int SubjectId { get; set; }
    public decimal CalculatedHours { get; set; }

}