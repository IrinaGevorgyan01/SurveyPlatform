﻿CREATE TYPE [dbo].[Ides] AS TABLE (
    [Id] INT NULL);

