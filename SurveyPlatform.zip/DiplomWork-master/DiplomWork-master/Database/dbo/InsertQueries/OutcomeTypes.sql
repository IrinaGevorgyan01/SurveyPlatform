﻿insert into OutcomeTypes([Title]) values(N'Գիտելիք')
insert into OutcomeTypes([Title]) values(N'Կարողություն')
insert into OutcomeTypes([Title]) values(N'Հմտություն')