﻿CREATE TABLE OutcomeTypes (
    [Id] INT PRIMARY KEY IDENTITY(0,1),
    [Title] NVARCHAR(100) not null
)