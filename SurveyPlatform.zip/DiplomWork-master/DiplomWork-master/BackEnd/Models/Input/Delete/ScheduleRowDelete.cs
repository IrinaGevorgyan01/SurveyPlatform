﻿namespace BackEnd.Models.Input;
public class ScheduleRowDelete
{
        public int ScheduleId { get; set; }
        public int SubjectId { get; set; }
}