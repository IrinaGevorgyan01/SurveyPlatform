﻿namespace BackEnd.Models.Input
{
    public class RecipientGroupPost
    {
        public string? Name         { get; set; }
        public int     DepartmentId { get; set; }
        public string? Description  { get; set; }
    }
}