﻿namespace FrontEnd.Model;

public class ResetPassPost
{
    public string UserEmail { get; set; }

}