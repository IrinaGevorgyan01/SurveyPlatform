﻿using AutoMapper;
using FrontEnd.Interface;
using FrontEnd.Model;
using FrontEnd.Model.DTO;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using static MudBlazor.CategoryTypes;

namespace FrontEnd.Pages.Shared
{
    public partial class SomethingWrong
    {
       
    }
}