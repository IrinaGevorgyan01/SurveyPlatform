﻿CREATE TYPE RatingType AS TABLE
(
    Id        INT,
    FormRowId INT,
    Value DECIMAL(18, 2)
);