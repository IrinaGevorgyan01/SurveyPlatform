﻿namespace FrontEnd.Model.Dialog;

public class SemesterDialog
{
    public string Name { get; set; }
    public int Hours { get; set; }
}