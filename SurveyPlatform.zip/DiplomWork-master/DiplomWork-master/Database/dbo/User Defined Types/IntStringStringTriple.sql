﻿CREATE TYPE [dbo].[IntStringStringTriple] AS TABLE (
    [Item1] INT            NULL,
    [Item2] NVARCHAR (MAX) NULL,
    [Item3] NVARCHAR (MAX) NULL);

