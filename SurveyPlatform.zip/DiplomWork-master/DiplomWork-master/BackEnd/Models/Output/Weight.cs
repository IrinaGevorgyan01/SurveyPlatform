﻿namespace BackEnd.Models.Output
{
    public class Weight
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public float Value { get; set; }
    }
}
