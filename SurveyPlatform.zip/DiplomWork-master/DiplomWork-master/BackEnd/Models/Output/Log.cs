﻿namespace BackEnd.Models.Output
{
    public class Log
    {
        public  string? Name { get; set; }
        public  string? Data { get; set; }
    }
}
