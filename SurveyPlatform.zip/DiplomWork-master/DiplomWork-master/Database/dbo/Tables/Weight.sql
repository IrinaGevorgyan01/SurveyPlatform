﻿CREATE TABLE Weight (
    [Id] INT PRIMARY KEY IDENTITY(0,1),
    [Name] NVARCHAR(50),
	[Weight] FLOAT
)

