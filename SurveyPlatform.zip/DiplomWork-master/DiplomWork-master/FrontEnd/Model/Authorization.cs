﻿namespace FrontEnd.Model;

public class AuthorizationPost
{
    public string LogIn { get; set; }
    public string Password { get; set; }
}