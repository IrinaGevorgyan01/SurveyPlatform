namespace FrontEnd.Model.DTO;

public class SubjectDto
{
    public int Id {  get; set; }
    public int Order {  get; set; }
    public string? Title { get; set; }
    public string? Outcome { get; set; }
    
}