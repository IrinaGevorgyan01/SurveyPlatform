﻿CREATE TYPE [dbo].[StringTuple] AS TABLE (
    [Item1] NVARCHAR (MAX) NULL,
    [Item2] NVARCHAR (MAX) NULL);

