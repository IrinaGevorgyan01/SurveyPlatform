﻿namespace BackEnd.Models.Output;
public class Form
{
        public int Id { get; set; }
        public int GroupId { get; set; }
        public string? Name { get; set; }
        public int DepartmentId { get; set; }
        public string? Description { get; set; }
}
