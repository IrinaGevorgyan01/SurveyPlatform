﻿namespace BackEnd.Models.Input;
public class ScheduleRowPost
{
        public int ScheduleId { get; set; }
        public int SubjectId { get; set; }
}