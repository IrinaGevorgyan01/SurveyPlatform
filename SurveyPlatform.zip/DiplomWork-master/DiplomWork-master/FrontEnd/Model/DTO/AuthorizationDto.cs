namespace FrontEnd.Model;

public class AuthorizationDto
{
    public string LogIn { get; set; }
    public string Password { get; set; }
}