namespace BackEnd.Models.Output;

public class SubjectOptimized
{
    public int SubjectId { get; set; }
    public decimal CalculatedHours { get; set; }
}