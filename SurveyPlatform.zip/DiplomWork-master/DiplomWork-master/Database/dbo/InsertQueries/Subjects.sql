﻿begin transaction
--ՏԱ
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Հաշվողական համակարգերում կիրառվող մաթեմատիկական հիմուքնների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Մաթեմատիկան գործնական խնդիրներում օգտագործելու կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Դիսկրետ կառուցվածքների մշակման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Հաշվողական համակարգերի գործընթացների վերլուծության ունակություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ալգորիթմներ և ծրագրավորում', '' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օբյեկտ կողմնորոշված ծրագրավորում', '' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Տեղեկատվական համակարգերին սպառնացող վտանգների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռհարձակումներից պաշտպանության եղանակների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռանանգության ապահովման հիմնական գործիքամիջոցների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռանվտանգությունն ապահովող գործիքամիջոցների կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Տեղեկատվական համակարգերը հիմնական կիբեռհարձակումներից պաշտպանելու կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'ՕՀ գործառույթների, տեսակների, կառուցվածքի, ֆայլային համակարգի իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Հրամանային տողի իմացություն, ֆայլերի, տեքստի, հետ աշխատանքի ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Bash ինտերֆեյսի իմացություն, bash լեզվի կառուցվածքների իմացություն, ծրագրեր գրելու կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Պրոցեսների հետ աշխատանքի, ղեկավարման, մոնիտորինգի ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Ազդանշանների իմացություն, տարբեր մեթոդներով ազդանշան ուղարկելու և մշակելու կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային համակարգեր և ցանցեր', '' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքեր', '' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Տեղեկատվական անվտանգություն մասնագիտության մասին ընդհանուր գիտելիքների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Տեղեկատվական անվտանգություն մասնագիտության զարգացման ուղղությունների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Մասնագիտական գործունեության համար անհրաժեշտ գործիքամիջոցների կիրառման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրավորման տեխնոլոգիաներ', N'Ծրագրավորման օբյեկտ-կողմնորոշված մեթոդի կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրավորման տեխնոլոգիաներ', N'Օպերացիոն համակարգի միջավայրում պատուհանային երկխոսություն ապահովող դասերի գրադարանների կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրավորման տեխնոլոգիաներ', N'Ծրագրավորման եղանակների կիրառման ունակություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'ՕՀ հարձակումների տիպերի իմացություն և դրանցից պաշտպանության մեխանիզմների կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'ՕՀ աբստրակտ ռեսուրսների և դրանց հետ աշխատանքի առաձնահատկությունների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'Օպերացիոն համակարգերում տվյալների անվտանգությունն ապահովող գործիքամիջոցների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'Ոչ ստանդարտ վարքագիծը հայտնաբերելու նպատակով տվյալների աուդիտ, հաշվառում և գրանցում կատարելու ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'Օպերացիոն համակարգը անվտանգության պահանջներին համապատասխան արգաբերելու կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի անվտանգություն', N'Docker ծրագրային միջոցի տիրապետում, անվտանգության կոնցեպտների իմացություն և կիրառման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի անվտանգություն', N'Տվյալների հենքերում իրավասությունների բաշխման եղանակների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի անվտանգություն', N'Տվյալների հենքերում հարցումների արագագործության բարձրացման մեթոդների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի անվտանգություն', N'Տվյալների հենքերի անվտանգության ապահովման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Վնասակար ծրագրերի տարածման կանխարգելում', N'Կիբեռմիջավայրում հանդիպող գրոհների տեսակների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Վնասակար ծրագրերի տարածման կանխարգելում', N'Կիբեռմիջավայրում հնարավոր գրոհների հայտաբերման ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Վնասակար ծրագրերի տարածման կանխարգելում', N'Կիբեռմիջավայրում գրոհներից հնարավոր վնասները գնահատելու կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Վնասակար ծրագրերի տարածման կանխարգելում', N'Կիբեռմիջավայրում գրոհներին հակազդելու կարողություն' , 0)
                                                                      
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության գաղտնագրային պաշտպանություն', N'Արդի գաղտնագրության և թաքնագրության տեսական և կիրառական գործիքաշարերի իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության գաղտնագրային պաշտպանություն', N'Գաղտնագրության մեթոդների վերլուծության և կիրառման տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության գաղտնագրային պաշտպանություն', N'Գաղտնագրային և թաքնագրային համակարգերի գործնական պաշտպանվածության գնահատման կարողություններ' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Գաղտնագրային բանալիների և գաղտնաբառերի կառավարում', N'Տեղեկատվական համակարգերում գաղտնագրային պաշտպանության բանալիների փոխանակման արձանագրությունների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Գաղտնագրային բանալիների և գաղտնաբառերի կառավարում', N'Տեղեկատվական համակարգերում գաղնտաբառերի կառավարման ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Գաղտնագրային բանալիների և գաղտնաբառերի կառավարում', N'Մշակվող ծրագրային համակարգերում բամալիների և գաղտնաբառերի կառավարման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Մշակվող ծրագրային համակարգերի անվտանգության ապահովման մեթոդների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Ծրագրային համակարգերի սպառնալիքների բացահայտման ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Մշակվող ծրագրային համակարգերը կրկնօրինակումից և չարտոնված կիրառումից պաշտպանող մեթոդների գործնական կիրառման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի անվտանգություն', N'Քոմփյութերային ցանցերի կազմակերպման և նախագծման մեթոդների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի անվտանգություն', N'Ցանցային համակարգերում տվյալների կառավարման և պաշտպանության արդի տեխնոլոգիաների կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի անվտանգություն', N'Քոմփյութերային ցանցերում տեղեկատվության փոխանակման հիմնական աձանագրությունների իմացություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների անվտանգություն', N'WEB կիրառությունների նախագծման և մշակման կարողություններ' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների անվտանգություն', N'WEB կիրառություններում ավտանգության ապահոման մեթոդների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների անվտանգություն', N'WEB կիրառություններում հիմնական սպառանալիքների իմացություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության պաշտպանություն չարտոնված մուտքերից', N'Ծրագրային համակարգերում իրավասությունների բաշխման մեթոդների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության պաշտպանություն չարտոնված մուտքերից', N'Տեղեկատվական համակարգերում մուտքի կառավարման եղանակների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության պաշտպանություն չարտոնված մուտքերից', N'Վավերականության ամբողջականության և գաղտնիության անվտանգ արձանագրությունների մշակման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ներթափանցումների թեստավորում', N'Տեղեկատվական համակարգերի անվտանգության խնդիրները վերհանելու եղանակների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ներթափանցումների թեստավորում', N'Տեղեկատվական համակարգերի կոտրման եղանակների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ներթափանցումների թեստավորում', N'Տեղեկատվական համակարգերի վրա փորձնական գրոհների միջոցով անվտանգության փորձարկելու կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների անվտանգություն', N'Մոբայլ կիրառությունների նախագծման ունակություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների անվտանգություն', N'Մոբայլ կիրառությունների անվտանգության ապահովման հիմնական մեթոդների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների անվտանգություն', N'Անվտանգ մոբայլ կիրառությունների մշակման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության անվտանգության ռիսկերի կառավարում', N'Տեղեկատվական անվտանգության ռիսկերի բացահայտման միջոցների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության անվտանգության ռիսկերի կառավարում', N'Տեղեկատվական անվտանգության ռիսկերի գնահատման և զսպման մեթոդների իմացություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տեղեկատվության անվտանգության ռիսկերի կառավարում', N'Իրական բիզնես գործընթացներում տեղեկատվական անվտանգության ռիսկերի կառավարման մոդելի կառուցման կարողություն' , 0)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ուսումնառության ողջ ընթացքում ստացած գործնական և տեսական գիտելիքների տիրապետում' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ուսումնառության ողջ ընթացքում ստացած գիտելիքների գործնական կիրառման կարողություն' , 0)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ծավալուն և ավարտուն աշխատանք իրականացնելու կարողություն' , 0)

 -------------------------------------------------------------------------------
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Հաշվողական համակարգերում կիրառվող մաթեմատիկական հիմուքնների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Մաթեմատիկան գործնական խնդիրներում օգտագործելու կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Դիսկրետ կառուցվածքների մշակման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ինֆորմատիկայի մաթեմատիկական հիմունքներ', N'Հաշվողական համակարգերի գործընթացների վերլուծության ունակություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ալգորիթմներ և ծրագրավորում', '' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օբյեկտ կողմնորոշված ծրագրավորում', '' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Տեղեկատվական համակարգերին սպառնացող վտանգների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռհարձակումներից պաշտպանության եղանակների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռանանգության ապահովման հիմնական գործիքամիջոցների տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Կիբեռանվտանգությունն ապահովող գործիքամիջոցների կիրառման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Կիբեռանվտանգության հիմունքներ', N'Տեղեկատվական համակարգերը հիմնական կիբեռհարձակումներից պաշտպանելու կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'ՕՀ գործառույթների, տեսակների, կառուցվածքի, ֆայլային համակարգի իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Հրամանային տողի իմացություն, ֆայլերի, տեքստի, հետ աշխատանքի ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Bash ինտերֆեյսի իմացություն, bash լեզվի կառուցվածքների իմացություն, ծրագրեր գրելու կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Պրոցեսների հետ աշխատանքի, ղեկավարման, մոնիտորինգի ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հիմունքներ', N'Ազդանշանների իմացություն, տարբեր մեթոդներով ազդանշան ուղարկելու և մշակելու կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային համակարգեր և ցանցեր', '' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքեր', '' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Ծրագրային ճարտարագիտություն մասնագիտության մասին ընդհանուր գիտելիքների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Ծրագրային ճարտարագիտություն մասնագիտության զարգացման ուղղությունների տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մասնագիտական ներածություն', N'Մասնագիտական գործունեության համար անհրաժեշտ գործիքամիջոցների կիրառման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորում', N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորման սկբունքների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորում', N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորման մեթոդների կիրառմամբ ծրագրային ապահովման նախագծում(կառուցվածք)' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորում', N'Օբյեկտ կողմնորոշված և կոմպոնենտային ծրագրավորման մեթոդների կիրառմամբ ծրագրային ապահովման մշակման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի նախագծում', N'Տվյալների հենքերի նախագծման եղանակների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի նախագծում', N'Մեծածավալ տվյալների հենքեր ստեղծելու և դրանց հետ արդյունավետ աշխատելու մեթոդների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի նախագծում', N'Տրված խնդրի համար արդյունավետ տվյալների հենքեր նախագցելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների հենքերի նախագծում', N'Տվյալների հենքերի արդյունավետության բարձացման և նոր տվյալների հենքերի նախագծման մեթոդները գործնականում կիրառելու կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'ՕՀ կողմից տրամադրվող աբստրակտ ռեսուրսների իմացություն։ C լեզվի ստանդարտ գրադարանների միջոցով ՕՀ ռեսուրսների հետ աշխատելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'Հաղորդագրությունների հերթեր ստեղծելու, կիրառելու, ղեկավարելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'Պրոցեսների սինխրոն աշխատանքի համար ծրագրեր մշակելու ունակություն, ընդհանուր հիշողության հետ պրոցեսների աշխատանքի կարգավորման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'Հոսքերի հետ աշխատանքի կարողություն, աշխատանքի ճիշտ կազմակերպում, փակուղային իրավիճակներից խուսափող ծրագրեր մշակելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'Սոկետների հետ աշխատանքի կարողություն, տարբեր տիպի սոկետների աշխատանքի առանձնահատկությունների իմացություն, տարբեր դոմեյններում աշխատանքի կազմակերպման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Օպերացիոն համակարգերի հատուկ բաժիններ', N'Docker ծրագրային միջոցի իմացություն, պատկեր, կոնտեյներ, ներքին ցանց ստեղծելու ունակություն, ներքին ցանցի միջոցով կոնտեյներների հաղորդակցության ապահովում' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Համակարգային ծրագրավորում', N'Քոմփյութերում ամենացածր մակարդակի ծրագրավորման հիմնական առանձնահատկություների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Համակարգային ծրագրավորում', N'Մեքենայական լեզվով ծրագրի մշակման առանձնահատկությունների տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Համակարգային ծրագրավորում', N'Մեքենայական լեզվով ծրագրի մշակման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի ծրագրավորում', N'Քոմփյութերային ցանցերով աշխատող ծրագրերի առանձնահատկությունների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի ծրագրավորում', N'Քոմփյութերային ցանցերով տեղեկատվություն փոխանակող ծրագրերի նախագծման ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Քոմփյութերային ցանցերի ծրագրավորում', N'WINDOWS և LINUX օպերացիոն համակարգերում քոմփյութերային ցանցերով աշխատող ծրագրային համակարգերի մշակման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների նախագծում', N'WEB-ում տվյալների փոխանակման հիմնական արձանագրությունների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների նախագծում', N'WEB սերվերների տեղադրման և համապատասխան կարգաբերման ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'WEB կիրառությունների նախագծում', N'WEB հենքով աշխատող ծրագրերի մշակման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Արհեստական բանականության ծրագրամիջոցների նախագծում', N'Արհեստական բանականության և մեքենայական ուսուցման ժամանակակից գրադարանների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Արհեստական բանականության ծրագրամիջոցների նախագծում', N'Ծրագրային համակարգերի մշակման ժամանակ արհեստական բանականության և մեքենայական ուսուցման ալգորիթմներ ընտրելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Արհեստական բանականության ծրագրամիջոցների նախագծում', N'Ծրագրային համակարգերում արհեստական բանականության և մեքենայական ուսուցման ալգորիթմների գործնական կիրառման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների կառուցվածքներ և ծրագրավորում', N'Տվյալների հիմնական կառուցվածքների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների կառուցվածքներ և ծրագրավորում', N'Տվյալների կառուցվածքների հետ աշխատելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների կառուցվածքներ և ծրագրավորում', N'Ծրագրային ապահովման մշակման ընթացքում տվյալների կառուցվածքների կիրառման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Տվյալների կառուցվածքներ և ծրագրավորում', N'Տվյալների կառուցվածքների հետ արդյունավետ աշխատելու ալգորիթմների իմացություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների նախագծում', N'Մոբայլ օպերացիոն համակարգերում կիրառական ծրագրերի առանձնահատկությունների  իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների նախագծում', N'Մոբայլ կիրառությունների նախագծման հիմնական մեթոդների  տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Մոբայլ կիրառությունների նախագծում', N'Մոբայլ օպերացիոն համակարգերում աշխատող կիրառական ծրագրերի մշակման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ամպային տեխնոլոգիաներ', N'Ամպային միջավայրում աշխատող ծրագրային համակարգերի աշխատանքի առանձնահատկությունների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ամպային տեխնոլոգիաներ', N'Ամպային միջավայրերում աշխատելու համար նախատեսված ծրագրային համակարգեր նախագծելու ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ամպային տեխնոլոգիաներ', N'Ամպային միջավայրում աշխատող ծրագրային համակարգի մշակման և կարգաբերման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրերի թեստավորում', N'Ծրագրային ապահովման աշխատունակության և որակի թեստավորման հիմնական մեթոդների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրերի թեստավորում', N'Ծրագրային համակարգերում սխալների բացահայտման ավտոմատացված մեթոդների կիրառման ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրերի թեստավորում', N'Ծրագրային համակարգերի թեստավորման միջոցով կայունության և որակի բարձրացման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Մշակվող ծրագրային համակարգերի անվտանգության ապահովման մեթոդների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Ծրագրային համակարգերի սպառնալիքների բացահայտման ունակություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային ապահովման անվտանգություն', N'Մշակվող ծրագրային համակարգերիը կրկնօրինակումից և չարտոնված կիրառումից պաշտպանող մեթոդների գործնական կիրառման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային նախագծերի որակի ապահովում և կառավարում', N'Ծրագրային համակարգերի մշակման կյանքի ցիկլի իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային նախագծերի որակի ապահովում և կառավարում', N'Ծրագրային նախագծերի կառավարման մեթոդների իմացություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային նախագծերի որակի ապահովում և կառավարում', N'Ծրագրային նախագծերում որակի ապահովման եղանակների տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ծրագրային նախագծերի որակի ապահովում և կառավարում', N'Գործնականում ծրագրային համակարգի կառավարման կարողություն' , 1)

INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ուսումնառության ողջ ընթացքում ստացած գործնական և տեսական գիտելիքների տիրապետում' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ուսումնառության ողջ ընթացքում ստացած գիտելիքների գործնական կիրառման կարողություն' , 1)
INSERT INTO Subjects(Title, outcome, DepartmentId) values(N'Ավարտական աշխատանք', N'Ծավալուն և ավարտուն աշխատանք իրականացնելու կարողություն' , 1)

commit transaction