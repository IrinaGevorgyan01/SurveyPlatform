namespace FrontEnd.Helpers;

public enum Os
{
    Undefined = 0,
    Windows  = 1,
    UnixLinux = 2,
    MacOs = 3
}