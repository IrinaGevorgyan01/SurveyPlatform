﻿namespace FrontEnd.Interface;

// public interface IConfigurationService
// {
//     public static string URL { get; set; }
//     public static string PORT { get; set; }
//     
// }