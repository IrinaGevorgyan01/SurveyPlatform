﻿using System.ComponentModel.DataAnnotations;

namespace BackEnd.Models.Input
{
    public class LogPost
    {
        public  DateTime? Date { get; set; }
    }
}
